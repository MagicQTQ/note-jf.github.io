var a="/assets/true-image-20210601002120191.9e44b91a.png";export{a as _};
