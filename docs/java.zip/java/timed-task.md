---
icon: edit
title: 定时任务
category: Java
date: 2020-01-01
tag:
- 定时任务
---


![](./timed-task.assets/true-up-795f5e9b0d875063717b1ee6a08f2ff1c01.png)


